const request = require("request");
const _ = require("lodash");
const Promise = require('bluebird');

const AWS = require("aws-sdk");

var tableName = process.env.userStationsTableName;

const localCredentials = {
    region: 'us-east-1',
    accessKeyId: 'local',
    secretAccessKey: 'local'
};

const awsCredentials = {
    region: 'us-east-1',
    accessKeyId: process.env.accessKeyId,
    secretAccessKey: process.env.secretAccessKey
};

const localURL = 'http://localhost:8000';
var localDynasty = require('dynasty')(localCredentials, localURL);

var awsDynasty = require('dynasty')(awsCredentials);

var dynasty = localDynasty;

var userStationsTable;

var devDeviceId = 'dev-12345';
/*
const dynamodb = new AWS.DynamoDB.DocumentClient({
    
  region: "localhost",
  endpoint: "http://localhost:8000"
});
*/

const DBhelper = {
  getStationsById: function(deviceId) {
    let stations = [];

    return stations;
  },

  setDynasty : function() {
    console.log('setDynasty stage = ' + process.env.stage);
    if(process.env.stage === 'dev' || process.env.stage === 'prd'){
      
      dynasty = awsDynasty;
    }
  },

  testRead: function() {
    DBhelper.setDynasty();
    userStationsTable = dynasty.table(tableName);

    userStationsTable.find(devDeviceId)
    .then(function(result){
        console.log('station distance = ' + result.stations.length);
        //console.log('user stations = ' + JSON.stringify(result.stations, null, '\t'));
        return result;
    })
    .catch(function(error){
        console.log(error);
    })
  },

  testPut: function() {
    DBhelper.setDynasty();
    userStationsTable = dynasty.table(tableName);

    console.log('testPut : ' + userStationsTable);
    
    let aStations = [{"stopID": "R20", "distance": "0.2", "duration": "5 mins"}]
    
    userStationsTable.insert({
        userId: devDeviceId,
        stations: aStations
    }).catch(function(error){
        console.log('testPut: error = ' + error);
    })

    return 
  }
};

module.exports = DBhelper;